const mongoose = require('mongoose');

var getMongose = function () {
  return mongoose;
}

class DbConnection {
  constructor(port, address, dbName) {
    this.port = port;
    this.address = address;
    this.dbName = dbName;
  }


  connectToDB(callback) {
    let dbURI = 'mongodb://' + this.address + ':' + this.port + '/' + this.dbName;
    /* Create the database connection */
    mongoose.connect(dbURI, {
      server: {
        socketOptions: {
          socketTimeoutMS: 0,
          connectionTimeout: 0,
        }
      }
    });

    /* Successfully connected */
    mongoose.connection.on('connected', function () {
      console.log('--------------------------------------------');
      console.log('Mongoose default connection open to ' + dbURI);
      callback(true);
    });

    /* Connection Error */
    mongoose.connection.on('error', function (err) {
      console.log('Mongoose default connection error: ' + err);
      callback(false);
    });

    /* Disconnected */
    mongoose.connection.on('disconnected', function () {
      console.log('Mongoose default connection disconnected');
      callback(false);
    });

    /* If the Node process ends, close the Mongoose connection */
    process.on('SIGINT', function () {
      mongoose.connection.close(function () {
        console.log('Mongoose default connection disconnected through app termination');
        process.exit(0);
      });
    });

  }
}

module.exports = {
  DbConnection, getMongose
};
