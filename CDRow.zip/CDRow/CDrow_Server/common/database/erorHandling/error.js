const errorList = require('./errorText.json');
const util = require('util');

class Error {
    constructor() {
        this.errorCode = null;
        this.errorMessage = null;
        this.stack = null;
    }

    setError(error) {
        switch (error.name) {
            case 'AlreadyExist':
                this.errorCode = '01';
                this.errorMessage = util.format(errorList['01'], error.field);
                this.stack = error.stack;
                break;
            case 'MissingParameter':
                this.errorCode = '02';
                this.errorMessage = errorList['02'];
                this.stack = error.stack;
                break;
            case 'ValidationError':
                this.errorCode = '03';
                this.errorMessage = error.field;
                this.stack = error.stack;
                break;
        }
        return this;
    }
}
module.exports = { Error };
