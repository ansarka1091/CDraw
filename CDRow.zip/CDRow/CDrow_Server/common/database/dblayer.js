let mongose = require('./connection').getMongose();
mongose.Promise = require('q').Promise;

const error = require('./erorHandling/error');
class DBLayer {
    constructor() {
        this.errorObj = new error.Error();
    }

    insertDocument(model, callback) {
        let promise = model.save();
        promise.then((res) => {
            return callback(null, res);
        }).catch((err) => {
            if (err.name === 'ValidationError') {
                let errorDetails = this.errorObj.setError({ name: err.name, field: err.message });
                return callback(errorDetails);
            }
            else {
                let errorDetails = this.errorObj.setError(err);
                return callback(errorDetails, null);
            }

        });
    }

    getAlldocuments(model, selectdColumn, callback) {
        let promise = model.find({});
        if (selectdColumn) {
            promise = model.find({}, selectdColumn);
        }

        promise.then((resp) => {
            return callback(null, resp);
        }).catch((err) => {
            let errorDetails = this.errorObj.setError(err);
            return callback(errorDetails, null);
        });
    }

    getDocumentBycondition(model, condition, callback) {
        var promise = model.findOne(condition);
        promise.then((resp) => {
            return callback(null, resp);
        }).catch((err) => {
            let errorDetails = this.errorObj.setError(err);
            return callback(errorDetails, null);
        });
    }

    upsert(model, updateObj, callback) {
        let promise = model.update({}, {
            $set: updateObj
        },
            { upsert: true });
        promise.then((resp) => {
            if (resp.n > 0) {
                return callback(null, 'The %s updates successfully');
            }
            else {
                let errorDetails = this.errorObj.setError({ name: 'ItemNotExist' });
                return callback(errorDetails, null);
            }
        }).catch((err) => {
            let errorDetails = this.errorObj.setError(err);
            return callback(errorDetails, null);
        });
    }

}

module.exports = { DBLayer };