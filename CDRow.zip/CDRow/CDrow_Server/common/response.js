class Response {
    constructor() {
        this.status = 'ok';
        this.errorCode = 0;
        this.message = 'na';
        this.data = null;
    }

    getOkResponse() {
        this.status = 'ok';
        this.errorCode = 0;
        this.message = 'Success';

        return this.toJsonString();
    }

    getErrorResponse(errorCode, errMsg) {
        this.status = 'error';
        this.errorCode = errorCode;
        this.message = errMsg;
        this.data = null;
        return this.toJsonString();
    }

    toJsonString() {
        return JSON.stringify(this);
    };
}

module.exports = { Response };