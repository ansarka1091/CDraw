const responseModule = require('../../../common/response');
let response = new responseModule.Response();
const canvasManager = require('../managers/canvas.manager');
const canvasManagerObj = new canvasManager.Canvas();
class Canvas {
    constructor(app) {

        app.get('/canvas', function (req, res, next) {
            canvasManagerObj.get((err, data) => {
                if (err) {
                    return res.end(response.getErrorResponse(err.errorCode, err.errorMessage));
                }

                response.data = data;
                return res.end(response.getOkResponse());
            });
        });
    }

}
module.exports = { Canvas };