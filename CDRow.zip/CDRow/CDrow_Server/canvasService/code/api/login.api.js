const loginManager = require('../managers/login.manager');
const responseModule = require('../../../common/response');
let response = new responseModule.Response();
const loginManagerObj = new loginManager.Login();
class Login {
    constructor(app) {
        app.get('/login', function (req, res, next) {
            loginManagerObj.login(req.query, (err, data) => {
                if (err) {
                    return res.end(response.getErrorResponse(err.errorCode, err.errorMessage));
                }

                response.data = data;
                return res.end(response.getOkResponse());

            });

        });
    }
}
module.exports = { Login };