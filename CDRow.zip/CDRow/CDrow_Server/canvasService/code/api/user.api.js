const responseModule = require('../../../common/response');
let response = new responseModule.Response();
const userManager = require('../managers/user.manager');
const userManagerObj = new userManager.User();
class User {
    constructor(app) {
     
        let that = this;

        app.get('/user', function (req, res, next) {
            userManagerObj.get((err, data) => {
                if (err) {
                    return res.end(response.getErrorResponse(err.errorCode, err.errorMessage));
                }

                response.data = data;
                return res.end(response.getOkResponse());
            });
        });

        app.post('/user', function (req, res, next) {
            userManagerObj.create(req.body, (err, data) => {
                if (err) {
                    return res.end(response.getErrorResponse(err.errorCode, err.errorMessage));
                }

                response.data = data;
                return res.end(response.getOkResponse());
            });
        });

        app.put('/user', function (req, res, next) {
        });

        app.delete('/user', function (req, res, next) {
        });
    }
}
module.exports = { User };