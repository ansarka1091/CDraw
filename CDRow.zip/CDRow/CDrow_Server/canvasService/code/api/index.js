
const path = require('path');
const fs = require('fs');
const canvasAPi = require('./canvas.api');
const loginAPi = require('./login.api');
const userAPi = require('./user.api');
const bodyParser = require('body-parser');

class IndexApi {

    constructor(app) {

        app.use(bodyParser.json({ limit: '50mb' }));

        /** for cross site acccess */
        app.use(function (req, res, next) {
            res.header("Access-Control-Allow-Origin", "*");
            res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Response-Type");
            res.header("Access-Control-Allow-Methods", "POST, GET, PUT, DELETE, OPTIONS");
            next();
        });

        app.get('/', function (req, res, next) {
            res.sendFile(path.resolve(__dirname + '../../../../CDraw/dist/index.html'));
        });

        new canvasAPi.Canvas(app);
        new loginAPi.Login(app);
        new userAPi.User(app);
    };
}

module.exports = { IndexApi };



