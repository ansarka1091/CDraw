let mongos = require('../../../../common/database/connection').getMongose();
let canvasSchema = new mongos.Schema({
    canvasPositions: String,
    updatedOn: Date,
}, {
        'collection': 'canvas'
    });

let Canvas = module.exports = mongos.model('Canvas', canvasSchema);