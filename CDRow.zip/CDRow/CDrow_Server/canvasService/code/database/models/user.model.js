
let mongos = require('../../../../common/database/connection').getMongose();

let userSchema = new mongos.Schema({
    name: {
        type: String,
        validate: {
            isAsync: true,
            validator: function (v, cb) {
                setTimeout(function () {
                    /* jshint ignore:start */
                    User.find({
                        name: v
                    }, function (err, docs) {
                        cb(docs.length === 0);
                    });
                }, 5);
                /* jshint ignore:end */
            },
            message: 'user name already exists'
        },
        required: true
    },
    username: String,
    password: String,
    emailid: String,
    phone: String,
    createdOn: Date,
    status: String
}, {
        'collection': 'users'
    });

let User = module.exports = mongos.model('User', userSchema);
