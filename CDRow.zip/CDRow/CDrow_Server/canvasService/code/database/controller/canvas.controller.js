let canvasModel = require('../models/canvas.model');
let dbLayer = require('../../../../common/database/dblayer');
const util = require('util');
class Canvas {
    constructor() {
        this.dbLayerObj = new dbLayer.DBLayer();
    }

    get(callback) {
        this.dbLayerObj.getAlldocuments(canvasModel, null, (err, data) => {
            callback(err, data);
        });
    }

    create(parameters, callback) {
        let details = {};
        details.canvasPositions = parameters.canvasInfo;
        details.updatedOn = new Date();
        this.dbLayerObj.upsert(canvasModel, details, (err, data) => {
            callback(err, data);
        });
    }
}

module.exports = { Canvas };