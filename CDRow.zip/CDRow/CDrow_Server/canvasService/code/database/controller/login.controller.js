let userModel = require('../models/user.model');
let dbLayer = require('../../../../common/database/dblayer');
const util = require('util');
class Login {
    constructor() {
        this.dbLayerObj = new dbLayer.DBLayer();
    }

    login(parameters, callback) {

        console.log('parameters' , parameters);
        let condition = {};
        if (parameters.username) {
            condition.username = parameters.username;
        }

        if (parameters.password) {
            condition.password = parameters.password;
        }

        this.dbLayerObj.getDocumentBycondition(userModel, condition, (err, data) => {
            return callback(err, data);
        });
    }
}

module.exports = { Login };