let userModel = require('../models/user.model');
let dbLayer = require('../../../../common/database/dblayer');
const util = require('util');
class User {
    constructor() {
        this.dbLayerObj = new dbLayer.DBLayer();
    }

    get(callback) {
        this.dbLayerObj.getAlldocuments(userModel, null, (err, data) => {
            callback(err, data);
        });
    }

    create(parameters, callback) {

        let userInfo = {};
        userInfo.name = parameters.name;
        userInfo.username = parameters.username;
        userInfo.password = parameters.password;
        userInfo.emailid = parameters.email;
        userInfo.phone = parameters.phone;
        userInfo.status = 'active';
        userInfo.createdOn = new Date()

        let parsedAgent = new userModel(userInfo);

        this.dbLayerObj.insertDocument(parsedAgent, (err, data) => {
            callback(err, data);
        });
    }
}

module.exports = { User };