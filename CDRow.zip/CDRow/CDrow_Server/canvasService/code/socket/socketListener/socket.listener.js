const manager = require('../../managers/canvas.manager');
class Listener {
    constructor() {
        this.managerObj = new manager.Canvas();
    }

    addToDB(data) {
        this.managerObj.create({ canvasInfo: JSON.stringify(data) }, (err, data) => { 
            console.log('Data Saved SuccessFully');
        });
    }
}
module.exports = { Listener };