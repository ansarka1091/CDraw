const listener = require('./socketListener/socket.listener.js')
let ipObjMapper = { 'ip': '', client: '', name: '' };
let ipObjMappers = [];

class Socket {
    constructor(io) {
        this.io = io;
        this.listenerObj = new listener.Listener();
        this.initialize();
    }

    initialize() {
        let that = this;
        that.io.on('connection', function (client) {

            console.log('Client connected...', client.handshake.address);

            let address = client.handshake.address;
            let clientIpAddress = address.split(':')[3];

            ipObjMapper = { 'ip': '', client: '' };
            ipObjMapper.ip = clientIpAddress;
            ipObjMapper.client = client;
            ipObjMapper.name = '';

            /** add only newly connectd machines */
            let ipObj = ipObjMappers.filter(ipM => ipM.ip == ipObjMapper.ip);
            if (!ipObj.length)
                ipObjMappers.push(ipObjMapper);

            /**Reciving username from the client on login */
            client.on('login', function (name) {

                console.log('---------login----------', name);

                let address = client.handshake.address;
                let clientIpAddress = address.split(':')[3];


                /**Update the current client object with name for an IP */
                ipObjMappers.forEach((obj) => {
                    return obj.ip === clientIpAddress && (obj.name = name);
                });

                let users = [];
                ipObjMappers.forEach((res) => {
                    if (res.ip)
                        users.push({ ip: res.ip, name: res.name });
                });


                /**Sending the updated userlist to every client connectd */
                that.io.emit('activeUsers', JSON.stringify(users));

            });

            /**Recieving latest changed canvas value from client */
            client.on('changedCanvasValue', function (data) {

                /***save the latest changed canvas into the database */
                that.onEmit(data);

                /**emitting latest changed canvas value to every client client */
                that.io.emit('latestChangedCanvas', data);
            });

            /**called on client logout */
            client.on('logout', function (name) {

                let address = client.handshake.address;
                let clientIpAddress = address.split(':')[3];

                /**remove logout user from the collection */
                ipObjMappers = ipObjMappers.filter(res => res.ip !== clientIpAddress);

                let users = [];
                ipObjMappers.forEach((res) => {
                    if (res.ip)
                        users.push({ ip: res.ip, name: res.name });
                });


                /**Sending the updated userlist to every client connectd */
                that.io.emit('activeUsers', JSON.stringify(users));
            });

            /**Execute on client disconnect */
            client.on('disconnect', () => {

                let address = client.handshake.address;
                let clientIpAddress = address.split(':')[3];
                /**Remove the client from active connectd objects */
                ipObjMappers = ipObjMappers.map(ipM => ipM.ip != clientIpAddress);

            });

        });

        /**called on server disconnect */
        that.io.on('disconnect', () => {
            that.io.close();
        })
    }

    /**initialte databse operation */
    onEmit(data) {
        this.listenerObj.addToDB(data);
    }
}

module.exports = { Socket };