const controller = require('../database/controller/login.controller');
const error = require('../../../common/database/erorHandling/error');
const util = require('util');
class Login {
    constructor() {
        this.loginCtrlr = new controller.Login();
        this.errorObj = new error.Error();
    }

    login(parameters, callback) {

        if (!parameters.username | !parameters.password) {
            let errorDetails = this.errorObj.setError({ name: 'MissingParameter' });
            errorDetails.errorMessage = util.format(errorDetails.errorMessage, "username or password");
            return callback(errorDetails);
        }

        this.loginCtrlr.login(parameters, (err, data) => {
            callback(err, data);
        });
    }
}

module.exports = { Login };