const controller = require('../database/controller/canvas.controller')
class Canvas {
    constructor() {
        this.controllerObj = new controller.Canvas();
    }

    get(callback) {
        this.controllerObj.get((err, data) => {
            callback(err, data);
        });
    }

    create(parameters, callback) {
        this.controllerObj.create(parameters, (err, data) => { });
    }
}

module.exports = { Canvas };