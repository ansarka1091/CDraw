const controller = require('../database/controller/user.controller')
class User {
    constructor() {
        this.controllerObj = new controller.User();
    }

    get(callback) {
        this.controllerObj.get((err, data) => {
            callback(err, data);
        });
    }

    create(parameters, callback) {
        this.controllerObj.create(parameters, (err, data) => {
            callback(err, data);
        });
    }
}

module.exports = { User };