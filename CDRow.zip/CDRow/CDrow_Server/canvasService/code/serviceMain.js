const webServer = require('./server');
let webServerObj = new webServer.WebServer();
webServerObj.start();