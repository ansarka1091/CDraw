
class WebServer {
    constructor() {

    }

    start() {
        const express = require('express');
        const app = express();
        const server = require('http').createServer(app);
        const io = require('socket.io')(server);
        const dataBase = require('../../common/database/connection');

        let config = require('./serviceConfig.json');
        let dbPort = config.dbPort;
        let dbName = config.dbName;
        let dbIpAddress = config.dbIpAddress;

        let dbObj = new dataBase.DbConnection(dbPort, dbIpAddress, dbName);
        dbObj.connectToDB((resp) => {
            if (resp) {
                let port = parseInt(config.Port, 10);
                let loadAPI = new require('./api/index');
                new loadAPI.IndexApi(app);
                let socketServer = new require('./socket/socket.server');
                new socketServer.Socket(io);
                server.listen(port);
                console.log('---------------------------------------');
                console.log('Canvas Server listening at port:-', port);
                console.log('---------------------------------------')
            }
        });

        process.on('SIGINT', () => {
            console.log('SIGINT');
            setTimeout(() => {
                server.close(() => {
                    process.exit();
                });
            }, 3000);

        });
    }
}

module.exports = { WebServer };



