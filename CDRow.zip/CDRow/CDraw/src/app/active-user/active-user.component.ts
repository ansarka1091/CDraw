import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-active-user',
  templateUrl: './active-user.component.html',
  styleUrls: ['./active-user.component.css']
})
export class ActiveUserComponent implements OnInit {

  constructor() { }

  @Input()
  userInfo: any;

  ngOnInit() {
  }

  ngOnChanges() {
    if (this.userInfo.name == localStorage.getItem('username')) {
      this.userInfo.name = 'Me'
    }
  }

}
