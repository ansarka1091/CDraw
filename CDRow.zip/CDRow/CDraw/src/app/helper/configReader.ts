const dscConfig = {};
export class ConfigReader  {
    constructor() {
    }

    getIp() {
        return '10.18.1.47';
    }

    getPort() {
        return 4200;
    }
}