export class ResponseReader {
    resposeData: Response;
    constructor(data) {
        this.resposeData = data;
    }

    getStatus(): boolean {
        let status = false;
        if (this.resposeData && this.resposeData.status.toString().toUpperCase() == 'OK') {
            status = true;
        }
        return status;
    }

    getData() {
        if (this.resposeData) {
            return this.resposeData['data'];
        }
    }

    getMessage() {
        if (this.resposeData) {
            return this.resposeData['message'];
        }
    }
}