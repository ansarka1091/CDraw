import { Component, OnInit, ViewChild, ElementRef, Input, AfterViewInit } from '@angular/core';
import * as io from 'socket.io-client';
import { CanvasService } from './canvas.service';
import { LoginService } from '../login/login.service';
import { ResponseReader } from '../Helper/responseReader';
import { Observable } from 'Rxjs';
import { ConfigReader } from '../Helper/configReader';

@Component({
  selector: 'app-canvas',
  templateUrl: './canvas.component.html',
  styleUrls: ['./canvas.component.css']
})
export class CanvasComponent extends ConfigReader implements OnInit, AfterViewInit {
  private socket;
  private url = 'http://' + super.getIp() + ':' + super.getPort();
  users: any;
  @ViewChild('canvas') public canvas: ElementRef;
  coordinates: Array<any>;
  @Input() public width = 1024;
  @Input() public height = 600;
  private cx: CanvasRenderingContext2D;
  canvaDetails: any;
  subscription: any;
  currentColor: string;


  constructor(private canvasService: CanvasService, private loginService: LoginService) {
    super();
    if (!this.socket) {
      console.log('-----------------------------------');
      this.socket = io(this.url);
      this.registerevents();
      this.socket.emit('login', localStorage.getItem('username'));
    }

    this.currentColor = '#000000'
    this.coordinates = [];
    this.intialCanvasLoad();
  }

  ngOnInit() {
    this.subscription = this.loginService.getLogout()
      .subscribe(item => {
        this.socket.emit('logout');
      });
  }

  ngAfterViewInit() {

    // get the context
    const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;

    this.cx = canvasEl.getContext('2d');

    // set the width and height
    canvasEl.width = this.width;
    canvasEl.height = this.height;

    // canvasEl.style.width = this.canvas.nativeElement.height;
    // canvasEl.style.height = this.canvas.nativeElement.width;


    // set some default properties about the line
    this.cx.lineWidth = 3;
    this.cx.lineCap = 'round';
    // this.cx.strokeStyle = '#000';

    // we'll implement this method to start capturing mouse events
    this.captureEvents(canvasEl);
  }

  private captureEvents(canvasEl: HTMLCanvasElement) {
    Observable
      // this will capture all mousedown events from teh canvas element
      .fromEvent(canvasEl, 'mousedown')
      .switchMap((e) => {
        return Observable
          // after a mouse down, we'll record all mouse moves
          .fromEvent(canvasEl, 'mousemove')
          // we'll stop (and unsubscribe) once the user releases the mouse
          // this will trigger a 'mouseup' event    
          .takeUntil(Observable.fromEvent(canvasEl, 'mouseup'))
          // we'll also stop (and unsubscribe) once the mouse leaves the canvas (mouseleave event)
          .takeUntil(Observable.fromEvent(canvasEl, 'mouseleave'))
          // pairwise lets us get the previous value to draw a line from
          // the previous point to the current point    
          .pairwise()
      })
      .subscribe((res: [MouseEvent, MouseEvent]) => {
        const rect = canvasEl.getBoundingClientRect();

        // previous and current position with the offset
        const prevPos = {
          x: res[0].clientX - rect.left,
          y: res[0].clientY - rect.top
        };

        const currentPos = {
          x: res[1].clientX - rect.left,
          y: res[1].clientY - rect.top
        };

        // this method we'll implement soon to do the actual drawing
        this.drawOnCanvas(prevPos, currentPos);
      });
  }

  private drawOnCanvas(
    prevPos: { x: number, y: number },
    currentPos: { x: number, y: number }
  ) {

    // incase the context is not set
    if (!this.cx) { return; }

    // start our drawing path
    this.cx.beginPath();

    // we're drawing lines so we need a previous position
    if (prevPos) {

      this.coordinates.push({ "prevPos": prevPos, "currentPos": currentPos, "color": this.currentColor })

      this.cx.strokeStyle = this.currentColor;
      // sets the start point
      this.cx.moveTo(prevPos.x, prevPos.y); // from
      // draws a line from the start pos until the current position
      this.cx.lineTo(currentPos.x, currentPos.y);

      // strokes the current path with the styles we set earlier
      this.cx.stroke();
    }
  }

  intialCanvasLoad() {
    this.canvasService.getCanvas().subscribe(res => {
      let respObj = new ResponseReader(res);
      if (respObj.getStatus() && respObj.getData()) {
        this.canvaDetails = respObj.getData();
        if (this.canvaDetails && this.canvaDetails.length) {
          let cooordinates = JSON.parse(this.canvaDetails[0].canvasPositions);
          this.coordinates = cooordinates;
          this.drawCanvas(cooordinates, this.cx);
        }
      }
      else {
        this.canvaDetails = [];
      }
    });
  }

  registerevents() {

    this.socket.on('activeUsers', (data) => {
      console.log(JSON.parse(data));
      this.users = JSON.parse(data);
      this.users = this.users.filter(user => user.name != '' && user.name != undefined && user.name != null)
    });

    this.socket.on('latestChangedCanvas', (coordinates) => {
      this.drawCanvas(coordinates, this.cx);
    });
  }

  drawCanvas(cooordinates: any, obj: any) {
    for (let item in cooordinates) {
      obj.strokeStyle = cooordinates[item].color;
      // sets the start point
      obj.moveTo(cooordinates[item].prevPos.x, cooordinates[item].prevPos.y); // from
      // draws a line from the start pos until the current position
      obj.lineTo(cooordinates[item].currentPos.x, cooordinates[item].currentPos.y);
      obj.stroke();
    }
  }

  updateToRoom() {
    this.socket.emit('changedCanvasValue', this.coordinates);
  }

  Clear() {
    this.cx.clearRect(0, 0, this.width, this.height);
    this.coordinates = [];
  }

  Eraser() {
    if (this.currentColor == '#FFFFFF') {
      this.currentColor = '#000000';
    }
    else {
      this.currentColor = '#FFFFFF';
    }
  }

}
