import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConfigReader } from '../Helper/configReader';

@Injectable()
export class CanvasService extends ConfigReader {
  baseUrl: String;
  private socket;
  constructor(private _httpClient: HttpClient) {
    super();
    this.baseUrl = 'http://' + super.getIp() + ':' + super.getPort() + '/';
  }

  getCanvas() {
    console.log(this.baseUrl + 'canvas');
    return this._httpClient.get(this.baseUrl + 'canvas');
  }

  regitserEvents() {

  }

}
