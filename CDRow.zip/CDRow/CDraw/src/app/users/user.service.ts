import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';
import { ConfigReader } from '../Helper/configReader';

@Injectable()
export class UserService extends ConfigReader {
  baseUrl: String;
  constructor(private _httpClient: HttpClient) {
    super();
    this.baseUrl = 'http://' + super.getIp() + ':' + super.getPort() + '/';
  }

  getUsers() {
    return this._httpClient.get(this.baseUrl + 'user');
  }

  create(user: User) {
    return this._httpClient.post(this.baseUrl + 'user', user);
  }
}
