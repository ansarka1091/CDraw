import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms'
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component'
import { BrowserModule } from '@angular/platform-browser';
import { CanvasService } from './canvas/canvas.service';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { ActiveUserComponent } from './active-user/active-user.component';
import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { LoginComponent } from './login/login.component';
import { CanvasComponent } from './canvas/canvas.component';

import { AppRoutingModule } from './app-routing.module';
import { AuthGuardService } from './auth/auth-guard.service';
import { UserService } from './users/user.service';
import { UsersComponent } from './users/users.component';
import { LoginService } from './login/login.service';
import { RegisterComponent } from './register/register.component';



@NgModule({
    declarations: [AppComponent, ActiveUserComponent, LayoutComponent, HeaderComponent, FooterComponent, SidebarComponent, LoginComponent, CanvasComponent, UsersComponent, RegisterComponent],
    imports: [BrowserModule, HttpModule, HttpClientModule, AppRoutingModule, FormsModule, ReactiveFormsModule],
    providers: [CanvasService, AuthGuardService, UserService, LoginService],
    bootstrap: [AppComponent]
})
export class AppModule { }
