import { Component, Directive, ElementRef, AfterViewInit, Input, Renderer, ContentChild, ViewChildren, ViewChild } from '@angular/core';
import { Observable } from 'Rxjs';
import * as io from 'socket.io-client';
import { CanvasService } from './canvas/canvas.service';
import { ResponseReader } from './Helper/responseReader';
@Component({
    selector: 'app-route',
    templateUrl: './app.component.html'
})
export class AppComponent {

    constructor(private canvasService: CanvasService) {
    }
}
