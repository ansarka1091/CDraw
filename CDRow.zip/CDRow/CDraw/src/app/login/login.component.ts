import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ResponseReader } from '../Helper/responseReader';

import { User } from '../models/user.model';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loginmodel: User;
  errormessage: string;

  constructor(private fb: FormBuilder,
    private routrer: Router,
    private loginservice: LoginService) {
    this.errormessage = '';
    this.createForm();
  }

  ngOnInit() {
    localStorage.setItem('isAuthenticated', "false");
  }

  createForm() {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    })
  }

  onSubmit(formControlValues) {
    this.loginmodel = new User();
    this.loginmodel.username = formControlValues.username;
    this.loginmodel.password = formControlValues.password;



    this.loginservice.login(this.loginmodel).subscribe(data => {
      let respObj = new ResponseReader(data);
      if (respObj.getStatus() && respObj.getData()) {
        this.loginservice.loginStatus = true;
        localStorage.setItem('username', respObj.getData().name);
        this.routrer.navigate(['/user']);
      }
      else {
        this.errormessage = 'Invalid username or password';
        this.routrer.navigate(['/login']);
      }
    });
  }

}
