import { Injectable, EventEmitter } from '@angular/core';
import { Http, Response } from '@angular/http';
import { User } from '../models/user.model';
import { HttpClient } from '@angular/common/http';
import { ConfigReader } from '../Helper/configReader';
import 'rxjs/Rx';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';


// const loginDetails = require('../../../data/login.json');


@Injectable()
export class LoginService extends ConfigReader {
    baseUrl: String;
    loginDetails: any;
    logoutchange: EventEmitter<number> = new EventEmitter();

    private loggedIn = new BehaviorSubject<boolean>(false);
    constructor(private _httpClient: HttpClient) {
        super();
        this.baseUrl = 'http://' + super.getIp() + ':' + super.getPort() + '/';
    }

    get isLoggedIn() {
        return this.loggedIn.asObservable();
    }

    login(loginmodel: User) {
        return this._httpClient.get(this.baseUrl + 'login?username=' + loginmodel.username + '&password=' + loginmodel.password);

    }

    logout() {
        this.loggedIn.next(false);
        this.logoutchange.emit(1);
    }

    set loginStatus(status: boolean) {
        this.loggedIn.next(status);
    }

    getLogout() {
        return this.logoutchange;
    }


}
