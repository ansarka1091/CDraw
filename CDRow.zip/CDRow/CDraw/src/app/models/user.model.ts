export class User {
    name: string;
    username: string
    password: string
    email:string
    phone:number
}