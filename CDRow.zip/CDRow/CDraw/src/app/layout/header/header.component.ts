import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../login/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  username: any;
  constructor(private loginService :LoginService, private router: Router) {
    this.username = localStorage.getItem('username');
  }

  ngOnInit() {
  }

   logout() {
    this.loginService.logout();
    localStorage.setItem('username', "");
    localStorage.setItem('isAuthenticated', "false");
    this.router.navigate(['/login']);
  }

}
