import { Component, OnInit } from '@angular/core';
import { User } from '../models/user.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../users/user.service';
import { ResponseReader } from '../Helper/responseReader';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: User;
  errormessage: string;
  message = {};
  regisetrForm: FormGroup;
  constructor(private fb: FormBuilder, private userService: UserService) {
    this.message = { 'status': '', 'message': '' };
    this.user = new User();
    this.createForm();
  }

  ngOnInit() {
  }

  createForm() {
    this.regisetrForm = this.fb.group({
      name: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
    })
  }

  onSubmit(onSubmitformControlValues) {
    this.user.name = onSubmitformControlValues.name;
    this.user.username = onSubmitformControlValues.username;
    this.user.password = onSubmitformControlValues.password;
    this.user.email = onSubmitformControlValues.email;
    this.user.phone = onSubmitformControlValues.phone;

    this.userService.create(this.user).subscribe(res => {
      let respObj = new ResponseReader(res);
      if (respObj.getStatus() && respObj.getData()) {
        this.message['status'] = "ok";
        this.message['message'] = "User created successfully";
        return this.message;
      }
      else {
        this.message['status'] = "Error";
        this.message['message'] = respObj.getMessage();
      }
    });
  }
}
